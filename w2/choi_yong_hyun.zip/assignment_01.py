for n in range(5):
	print (4-n)*" " + (n+1)*"*"
