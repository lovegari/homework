for n in range(8):
	for m in range(9):
		left = n + 2
		right = m + 1
		mix = (n+2)*(m+1)
		print str(left) + "*" + str(right) + "=" + str(mix)