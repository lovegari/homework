result = 0
for n in range(51):
	result = result + n
print result