for n in range(6):
	print "*"*n